﻿using DSharpPlus.CommandsNext;
using DSharpPlus.CommandsNext.Attributes;
using DSharpPlus.Interactivity.Extensions;
using System.Threading.Tasks;

namespace DiscordBotEthan.Commands {

    public class Shush : BaseCommandModule {

        [Command("Shush")]
        public async Task ShushCommand(CommandContext ctx) {
            if (ctx.Member.Id != 447781010315149333)
                return;
            //.shush
            await ctx.RespondAsync("Wym Shush, fuck off.");
            await ctx.Channel.GetNextMessageAsync(ctx.Member);
            //stfu
            await ctx.RespondAsync("nn nig");
            await ctx.Channel.GetNextMessageAsync(ctx.Member);
            //wtf i could just turn you off rn
            await ctx.RespondAsync("Bet cause you can't handle the Heat");
        }
    }
}