﻿using DSharpPlus.CommandsNext;
using DSharpPlus.CommandsNext.Attributes;
using DSharpPlus.Entities;
using System;
using System.Threading.Tasks;

namespace DiscordBotEthan.Commands {
    public class Warn : BaseCommandModule {
        [Command("Warn"), RequirePermissions(DSharpPlus.Permissions.Administrator)]
        public async Task WarnCommand(CommandContext ctx, DiscordMember member, string reason) {
            var WarnS = await Program.PlayerSystem.GetPlayer(member.Id);
            WarnS.Warns.Add(reason);
            WarnS.Save(member.Id);

            DiscordEmbedBuilder Warns = new DiscordEmbedBuilder {
                Title = $"Warns | {member.Username}",
                Description = $"**{member.Mention} has been warned for the following Reason:**\n{reason}",
                Color = Program.EmbedColor,
                Footer = new DiscordEmbedBuilder.EmbedFooter { Text = "Made by JokinAce 😎" },
                Timestamp = DateTimeOffset.Now
            };
            await ctx.RespondAsync(embed: Warns);

            if (WarnS.Warns.Count >= 3) {
                DiscordRole muterole = ctx.Guild.GetRole(Program.MutedRole);
                await member.GrantRoleAsync(muterole);
                await member.SendMessageAsync("You got muted for 24 Hours because you have equal or more then 3 Warns.");
                await Task.Delay(86400000);
                await member.RevokeRoleAsync(muterole);
            }
        }

        [Command("Warns")]
        public async Task WarnsCommand(CommandContext ctx, DiscordMember member) {
            var WarnS = await Program.PlayerSystem.GetPlayer(member.Id);

            DiscordEmbedBuilder Warns = new DiscordEmbedBuilder {
                Title = $"Warns | {member.Username}",
                Description = WarnS.Warns.Count == 0 ? "**The User has no warnings**" : "**This User has following Warns:**\n" + string.Join("\n", WarnS.Warns.ToArray()),
                Color = Program.EmbedColor,
                Footer = new DiscordEmbedBuilder.EmbedFooter { Text = "Made by JokinAce 😎" },
                Timestamp = DateTimeOffset.Now
            };
            await ctx.RespondAsync(embed: Warns);
        }

        [Command("ClearWarns"), RequirePermissions(DSharpPlus.Permissions.Administrator)]
        public async Task ClearWarnsCommand(CommandContext ctx, DiscordMember member) {
            var WarnS = await Program.PlayerSystem.GetPlayer(member.Id);
            WarnS.Warns.Clear();
            WarnS.Save(member.Id);

            DiscordEmbedBuilder Warns = new DiscordEmbedBuilder {
                Title = $"Warns | {member.Username}",
                Description = $"**Warnings have been cleared for:**\n{member.Mention}",
                Color = Program.EmbedColor,
                Footer = new DiscordEmbedBuilder.EmbedFooter { Text = "Made by JokinAce 😎" },
                Timestamp = DateTimeOffset.Now
            };
            await ctx.RespondAsync(embed: Warns);
        }
    }
}