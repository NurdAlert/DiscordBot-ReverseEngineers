﻿using DSharpPlus.CommandsNext;
using DSharpPlus.CommandsNext.Attributes;
using DSharpPlus.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DiscordBotEthan.Commands {
    public class Tempmute : BaseCommandModule {

        [Command("Tempmute"), RequirePermissions(DSharpPlus.Permissions.Administrator)]
        public async Task TempmuteCommand(CommandContext ctx, DiscordMember member, string time) {
            double Time;

            if (time.EndsWith("d")) {
                Time = ConvertDaysToMilliseconds(Convert.ToDouble(time.Remove(time.Length - 1)));
            } else if (time.EndsWith("h")) {
                Time = ConvertHoursToMilliseconds(Convert.ToDouble(time.Remove(time.Length - 1)));
            } else if (time.EndsWith("m")) {
                Time = ConvertMinutesToMilliseconds(Convert.ToDouble(time.Remove(time.Length - 1)));
            } else if (time.EndsWith("s")) {
                Time = ConvertSecondsToMilliseconds(Convert.ToDouble(time.Remove(time.Length - 1)));
            } else {
                await ctx.RespondAsync("Time is invalid");
                return;
            }

            DiscordEmbedBuilder TempMute = new DiscordEmbedBuilder {
                Title = $"TempMute | {member.Username}",
                Description = $"**{member.Mention} has been muted for {time}\nUnmuted on {DateTime.Now.AddMilliseconds(Time):MM/dd/yyyy HH:mm}**",
                Color = Program.EmbedColor,
                Footer = new DiscordEmbedBuilder.EmbedFooter { Text = "Made by JokinAce 😎" },
                Timestamp = DateTimeOffset.Now
            };
            await ctx.RespondAsync(embed: TempMute);

            DiscordRole MutedRole = ctx.Guild.GetRole(Program.MutedRole);
            await member.GrantRoleAsync(MutedRole);
            await Task.Delay((int)Time);
            await member.RevokeRoleAsync(MutedRole);

            static double ConvertSecondsToMilliseconds(double seconds) {
                return TimeSpan.FromSeconds(seconds).TotalMilliseconds;
            }

            static double ConvertMinutesToMilliseconds(double minutes) {
                return TimeSpan.FromMinutes(minutes).TotalMilliseconds;
            }

            static double ConvertHoursToMilliseconds(double hours) {
                return TimeSpan.FromHours(hours).TotalMilliseconds;
            }

            static double ConvertDaysToMilliseconds(double days) {
                return TimeSpan.FromDays(days).TotalMilliseconds;
            }
        }
    }
}
