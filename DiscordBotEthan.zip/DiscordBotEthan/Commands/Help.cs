﻿using DSharpPlus.CommandsNext;
using DSharpPlus.CommandsNext.Attributes;
using DSharpPlus.Entities;
using System;
using System.Threading.Tasks;

namespace DiscordBotEthan.Commands {

    public class Help : BaseCommandModule {

        [Command("Help")]
        public async Task HelpCommand(CommandContext ctx) {
            DiscordEmbedBuilder Help = new DiscordEmbedBuilder {
                Title = "Help | Commands",
                Description = @"**.Help**
Shows all Commands

**.Ping**
Shows the current latency

**.Clear (amount)/all**
Removes a amount of messages or recreates the Channel

**.Tempmute <@User> Length(d/h/m/s)**
Temporarily mutes the User

**.Warn <@User> ""Reason""**
Warns the User with reason

**.Warns <@User>**
Shows all warnings for said User

**.ClearWarns <@User>**
Clears all warnings for said User",
                Color = Program.EmbedColor,
                Footer = new DiscordEmbedBuilder.EmbedFooter { Text = "Made by JokinAce 😎" },
                Timestamp = DateTimeOffset.Now
            };
            await ctx.RespondAsync(embed: Help);
        }
    }
}