﻿using DSharpPlus.CommandsNext;
using DSharpPlus.CommandsNext.Attributes;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DiscordBotEthan.Commands {
    public class Clear : BaseCommandModule {

        [Command("Clear"), RequirePermissions(DSharpPlus.Permissions.Administrator)]
        public async Task ClearCommand(CommandContext ctx, int amount) {
            try {
                var Messages = await ctx.Channel.GetMessagesAsync(amount + 1);
                await ctx.Channel.DeleteMessagesAsync(Messages);

                var msg = await ctx.RespondAsync($"{amount} messages deleted");
                await Task.Delay(3000);
                await msg.DeleteAsync();
            } catch (DSharpPlus.Exceptions.BadRequestException) {
                await ctx.RespondAsync("Messages are older then 14 Days\nDiscord API no like do .Clear all instead");
            }
        }

        [Command("Clear"), RequirePermissions(DSharpPlus.Permissions.Administrator)]
        public async Task ClearCommand(CommandContext ctx, string all) {
            if (all == "all") {
                try {
                    await ctx.Channel.CloneAsync();
                    await ctx.Channel.DeleteAsync();
                } catch (Exception) {
                    await ctx.RespondAsync("Something horrible happend, Command faulted");
                }
            }
        }
    }
}
