﻿using DSharpPlus;
using DSharpPlus.CommandsNext;
using DSharpPlus.Entities;
using DSharpPlus.Interactivity;
using DSharpPlus.Interactivity.Enums;
using DSharpPlus.Interactivity.Extensions;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DiscordBotEthan {

    internal class Program {
        public static DiscordClient discord;
        public static Stopwatch sw = Stopwatch.StartNew();
        public static DiscordColor EmbedColor = new DiscordColor("#3299E0");
        public static readonly ulong MutedRole = 765286908133638204;

        private static readonly string[] Statuses = new[] { "Allah is watchin", "Despacito", "Fuck", "Janitor cleanup", "Cheaing in CSGO", "EAC Bypass" };
        private static readonly ulong LearnerRole = 734242782092329101;
        private static readonly Random gen = new Random();

        private static void Main() {
            Console.WriteLine("Started");
            MainAsync().ConfigureAwait(false).GetAwaiter().GetResult();
        }

        private static async Task MainAsync() {
            discord = new DiscordClient(new DiscordConfiguration {
                Token = "TOKEN",
                TokenType = TokenType.Bot,
                MinimumLogLevel = LogLevel.Information,
                Intents = DiscordIntents.GuildMembers | DiscordIntents.AllUnprivileged
            });

            discord.Ready += (dc, args) => {
                _ = Task.Run(() => ThreadsShit.StatusChanger(dc));
                return Task.CompletedTask;
            };

            discord.GuildMemberAdded += async (dc, args) => {
                var Role = args.Guild.GetRole(LearnerRole);
                await args.Member.GrantRoleAsync(Role);
            };

            discord.MessageCreated += (dc, args) => {
                _ = Task.Run(async () => {
                    if (args.Author.IsBot)
                        return;

                    if (gen.Next(500) == 1) {
                        using WebClient client = new WebClient();
                        await args.Channel.SendMessageAsync(client.DownloadString("https://insult.mattbas.org/api/insult"));
                    }

                    if (args.Message.Attachments.Count > 0) {
                        foreach (var attach in args.Message.Attachments) {
                            if (attach.FileName.Contains("exe")) {
                                await args.Message.DeleteAsync("EXE File");

                                var WarnS = await PlayerSystem.GetPlayer(args.Author.Id);
                                WarnS.Warns.Add("Uploading a EXE File");
                                WarnS.Save(args.Author.Id);

                                DiscordEmbedBuilder Warns = new DiscordEmbedBuilder {
                                    Title = $"Warns | {args.Author.Username}",
                                    Description = $"**{args.Author.Mention} has been warned for the following Reason:**\nUploading a EXE File",
                                    Color = EmbedColor,
                                    Footer = new DiscordEmbedBuilder.EmbedFooter { Text = "Made by JokinAce 😎" },
                                    Timestamp = DateTimeOffset.Now
                                };
                                await args.Channel.SendMessageAsync(embed: Warns);

                                if (WarnS.Warns.Count >= 3) {
                                    DiscordRole muterole = args.Guild.GetRole(MutedRole);
                                    var member = await args.Guild.GetMemberAsync(args.Author.Id);
                                    await member.GrantRoleAsync(muterole);
                                    await member.SendMessageAsync("You got muted for 24 Hours because you have equal or more then 3 Warns.");
                                    await Task.Delay(86400000);
                                    await member.RevokeRoleAsync(muterole);
                                }

                            }
                        }
                    }

                });
                return Task.CompletedTask;
            };

            CommandsNextExtension commands = discord.UseCommandsNext(new CommandsNextConfiguration() {
                StringPrefixes = new[] { "." },
                EnableDefaultHelp = false,
                EnableMentionPrefix = false
            });

            commands.CommandErrored += async (dc, args) => {
                if (args.Exception is ArgumentException) {
                    await args.Context.RespondAsync("Arguments are missing");
                } else if (args.Exception is DSharpPlus.CommandsNext.Exceptions.CommandNotFoundException) {
                    await args.Context.RespondAsync("Couldn't find the Command use .Help");
                } else if (args.Exception is DSharpPlus.CommandsNext.Exceptions.ChecksFailedException) {
                    await args.Context.RespondAsync("You don't have rights for that Command");
                }
            };

            commands.RegisterCommands(Assembly.GetExecutingAssembly());

            discord.UseInteractivity(new InteractivityConfiguration() {
                PollBehaviour = PollBehaviour.KeepEmojis,
                Timeout = TimeSpan.FromSeconds(180)
            });

            await discord.ConnectAsync();
            await Task.Delay(-1);
        }

        public struct PlayerSystem {

            [JsonProperty("Warns")]
            public List<string> Warns { get; set; }

            public static async Task<PlayerSystem> GetPlayer(ulong id) {
                if (!File.Exists($"./Players/{id}.json"))
                    File.WriteAllText($"./Players/{id}.json", File.ReadAllText($"./Players/playertemplate.json"));

                string json;
                using (StreamReader sr = new StreamReader(File.OpenRead($"./Players/{id}.json"), new UTF8Encoding(false))) {
                    json = await sr.ReadToEndAsync().ConfigureAwait(false);
                }
                return JsonConvert.DeserializeObject<PlayerSystem>(json);
            }

            public void Save(ulong id) {
                File.WriteAllText($"./Players/{id}.json", JsonConvert.SerializeObject(this));
            }
        }

        public static class ThreadsShit {

            public static async void StatusChanger(DiscordClient dc) {
                while (true) {
                    foreach (var Status in Statuses) {
                        DiscordActivity activity = new DiscordActivity {
                            ActivityType = ActivityType.Playing,
                            Name = Status
                        };
                        await dc.UpdateStatusAsync(activity, UserStatus.DoNotDisturb);
                        dc.Logger.LogInformation("Status Update");
                        await Task.Delay(120000);
                    }
                }
            }
        }
    }
}